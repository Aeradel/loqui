settings = {
    'zipcode': '74012',
    'unit':'us'
}