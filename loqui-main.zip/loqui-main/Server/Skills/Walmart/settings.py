settings = {
    'walmartkey1':"6d498cd7e4ee5fc3d1a1f697c834a02c4646bd5bd2a3277da5f463745ff3397b",
    'walmartkey2':"bed472b02ac613b52c079d4d1342bab9f6cc8d57be94b7911616ab84cf119a3a",
    'walmartkey3':"6d5c823b6b90f3d894b91de6e3d595e6fbd04aca6d85607b5bf6187d5bed66ee",
    'walmartkey4':"327785813a47ecb1a62d8134e9ad95ec26e799306ad461c6f20e2c29196b9a81",
    'walmartkey5':"4885894ed0df353f0e2192f036a216aba5c8e35fcbe0c5ccf2316144143ce132",
    'store_id': 3295
}